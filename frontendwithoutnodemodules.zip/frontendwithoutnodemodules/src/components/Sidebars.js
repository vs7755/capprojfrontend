// (Kept for future growth—layout currently in AdminLayout)
// You can move the sidebar markup here if you prefer keeping layout cleaner.
export default function Sidebar() {
    return null;
  }