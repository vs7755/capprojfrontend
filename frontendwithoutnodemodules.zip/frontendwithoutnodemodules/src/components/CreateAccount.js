
import Crimg from '../Assests/sclogoyuva.jpg';
function Createaccount() {
    return (
        <div class="container-fluid d-flex align-items-center justify-content-center" style={{ backgroundColor:"#0055a5", backroundSize: "cover", backgroundPosition: "center", minHeight: "100vh" }}>
            <div style={{ maxWidth: "500px",width:"100%",margin: "0 auto" }}>
                <div class="card text-center mt-5 mb-5">
                    <div class="card-body" style={{ backgroundColor: "#45a049" }}>
                        <img class="card-img-top rounded-pill" src={Crimg} alt="Card image" style={{ width: '100px' }} />
                        <h4 class="text-light">Create Account</h4>
                        <form>
                            <div class="mb-3 mt-3">
                                <input type="text" class="form-control" id="firstname" placeholder="Enter First Name" name="fname" required />
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" id="lastname" placeholder="Enter Last Name" name="lname" required />
                            </div>
                            <div class="mb-3 mt-3">
                                <input type="email" class="form-control" id="email" placeholder="Enter Email" name="email" required />
                            </div>
                            <select class="form-select" id="sel1" name="sellist1" required>
                                <option>Select Type</option>
                                <option>User</option>
                                <option>Admin</option>
                            </select>
                            <br></br>
                            <div class="mb-3">
                                <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required />
                            </div>
                            <div class="mb-3">
                                <input type="password" class="form-control" id="confirmpassword" placeholder="Enter Confirm Password" name="conpswd" required />
                            </div>
                            <button type="submit" class="btn btn-info">Create Account</button>
                        </form>
                    </div>

                </div>

            </div>

        </div>


    )
}
export default Createaccount;