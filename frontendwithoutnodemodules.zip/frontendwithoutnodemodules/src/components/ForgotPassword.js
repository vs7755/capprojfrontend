import React, { useState } from "react";
import logo from "../Assests/sclogoshiva.png";
import { Link } from "react-router-dom";
function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
 
  const handleSendOtp = () => {
    if (!email) {
      alert("Please enter your email or username");
      return;
    }
    setOtpSent(true);
    alert(`OTP sent to ${email}`);
  };
 
  const handleVerify = () => {
    if (!otp) {
      alert("Please enter the OTP");
      return;
    }
    alert(`OTP verified: ${otp}`);
  };
 
  
  const containerStyle = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100vh",
    background: "linear-gradient(-45deg, #007b5e, #00a884, #00bcd4, #4cafef)",
    backgroundSize: "400% 400%",
    fontFamily: "Arial, sans-serif",
    margin: 0,
    animation: "gradientBG 8s ease infinite",
  };
 
  const cardStyle = {
    background: "white",
    padding: "40px",
    borderRadius: "12px",
    boxShadow: "0px 5px 10px rgba(0, 0, 0, 0.12)",
    textAlign: "center",
    width: "380px",
  };
 
  const logoStyle = {
    width: "95px",
    marginBottom: "20px",
  };
 
  const headingStyle = {
    marginBottom: "20px",
    color: "#003d6b",
    fontSize: "22px",
  };
 
  const inputStyle = {
    width: "100%",
    padding: "12px",
    margin: "10px 0",
    border: "1px solid #ccc",
    borderRadius: "7px",
    fontSize: "15px",
  };
 
  const buttonStyle = {
    width: "100%",
    padding: "12px",
    marginTop: "10px",
    backgroundColor: isHovered ? "#008f4a" : "#00a859", 
    color: "white",
    border: "none",
    borderRadius: "7px",
    fontSize: "15px",
    cursor: "pointer",
    transition: "background-color 0.3s ease",
  };
 
  return (
    <div style={containerStyle}>
      
      <style>
        {`
          @keyframes gradientBG {
            0% {background-position: 0% 50%;}
            50% {background-position: 100% 50%;}
            100% {background-position: 0% 50%;}
          }
        `}
      </style>
 
      <div style={cardStyle}>
        <img src={logo} alt="Standard Chartered Logo" style={logoStyle} />
        <h2 style={headingStyle}>Forgot Password</h2>
 
        <input
          type="text"
          placeholder="Enter Email / Username"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={inputStyle}
        />
 
        <button
          onClick={handleSendOtp}
          style={buttonStyle}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          Send OTP
        </button>
 
        {otpSent && (
          <>
            <input
              type="text"
              placeholder="Enter OTP"
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              style={inputStyle}
            />
            <Link to="/ResetPassword"
              onClick={handleVerify}
              style={buttonStyle}
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
            >
              Verify & Continue
            </Link>
          </>
        )}
      </div>
    </div>
  );
}
 
export default ForgotPassword;