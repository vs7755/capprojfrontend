import React from "react";
import logo from "../Assests/Logoseema.jpg";
import { Link } from "react-router-dom";
function ResetPassword(){
    return (
        <div className="d-flex justify-content-center align-items-center vh-100"
        style={{backgroundColor: "#f0f2f5"}}>
            
            <div className="card p-4 text-center justify-content-center align-items-center"
                 style={{width:"350px", borderRadius:"15px", 
                 backgroundColor: "#064cb2", boxShadow: "0 4px 12px rgba(0,0,0,0.1)",}}>
                <img src={logo} alt="logo" className="logo-img" style={{height: "68px", width: "178px", marginBottom: "10px"}}/>
                <div className="rounded-circle d-flex justify-content-center align-items-center mb-3"
                     style={{backgroundColor: "white", width:"140px", height:"140px",}} >

                    <svg width="90" height="90" viewBox="0 0 174 180" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <ellipse cx="87" cy="60" rx="29" ry="30" fill="#222222"/>
                        <path d="M86.9997 97.5C114.839 97.5 137.443 117.376 137.747 141.998C137.75 142.274 137.526 142.5 137.25 142.5H36.7497C36.4735 142.5 36.2494 142.274 36.2528 141.998C36.5564 117.376 59.1604 97.5001 86.9997 97.5Z" fill="#7E869E" fill-opacity="0.25"/>
                    </svg>

                </div>

                <h6 className="text-white mb-4">Reset Password</h6>
                <input type="password" placeholder="New Password" className="form-control text-center mb-3"
                style={{borderRadius: "8px", height: "45px", fontSize: "14px", backgroundColor: "white",}} />

                <input type="password" placeholder="Confirm Password" className="form-control text-center mb-4"
                style={{borderRadius: "8px", height: "45px", fontSize: "14px", backgroundColor: "white",}} /> 

                <Link to="/role-selection" className="btn w-100" style={{backgroundColor: "rgb(25 218 73)"}}>Reset Password</Link>        
            </div>
        </div>
    );
}

export default ResetPassword;