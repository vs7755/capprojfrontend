export const USERS = [
    { username: "misha.k", displayName: "Misha Kapoor" },
    { username: "valerie.t", displayName: "Valerie Trent" },
    { username: "admin.user", displayName: "Admin User" },
    { username: "rae.s", displayName: "Rae Singh" },
  ];