// Mock data to populate the table. Replace with API integration later.
const reports = [
    {
      id: 101,
      name: "Monthly AML Activity",
      category: "AML",
      status: "Generated",
      month: "2025-06",
      sideCategoryKey: "aml",
    },
    {
      id: 102,
      name: "Risk Exposure Summary",
      category: "Risk",
      status: "Generated",
      month: "2025-05",
      sideCategoryKey: "risk",
    },
    {
      id: 103,
      name: "Customer Profile Report",
      category: "Customer",
      status: "Generated",
      month: "2025-04",
      sideCategoryKey: "customer",
    },
    {
      id: 104,
      name: "AML Alerts – Q2",
      category: "AML",
      status: "Queued",
      month: "2025-07",
      sideCategoryKey: "aml",
    },
    {
      id: 105,
      name: "Operational Risk Heatmap",
      category: "Risk",
      status: "Failed",
      month: "2025-03",
      sideCategoryKey: "risk",
    },
  ];
  
  export default reports;